// SPDX-License-Identifier: LGPL-2.1-or-later
// Copyright (c) 2012-2014 Monty Program Ab
// Copyright (c) 2015-2023 MariaDB Corporation Ab
package org.mariadb.jdbc.client.column;

import java.sql.*;
import org.mariadb.jdbc.Configuration;
import org.mariadb.jdbc.client.ColumnDecoder;
import org.mariadb.jdbc.client.DataType;
import org.mariadb.jdbc.client.ReadableByteBuf;

/** Column metadata definition */
public class JsonColumn extends StringColumn implements ColumnDecoder {

  /**
   * JSON metadata type decoder
   *
   * @param buf buffer
   * @param charset charset
   * @param length maximum data length
   * @param dataType data type. see https://mariadb.com/kb/en/result-set-packets/#field-types
   * @param decimals decimal length
   * @param flags flags. see https://mariadb.com/kb/en/result-set-packets/#field-details-flag
   * @param stringPos string offset position in buffer
   * @param extTypeName extended type name
   * @param extTypeFormat extended type format
   */
  public JsonColumn(
      ReadableByteBuf buf,
      int charset,
      long length,
      DataType dataType,
      byte decimals,
      int flags,
      int[] stringPos,
      String extTypeName,
      String extTypeFormat) {
    super(buf, charset, length, dataType, decimals, flags, stringPos, extTypeName, extTypeFormat);
  }

  protected JsonColumn(JsonColumn prev) {
    super(prev);
  }

  @Override
  public JsonColumn useAliasAsName() {
    return new JsonColumn(this);
  }

  public String defaultClassname(Configuration conf) {
    return String.class.getName();
  }

  public int getColumnType(Configuration conf) {
    return Types.LONGVARCHAR;
  }

  public String getColumnTypeName(Configuration conf) {
    return "JSON";
  }
}
